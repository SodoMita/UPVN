"""
Sprite Renderer — 2D planes for characters (Tier2+)
Hybrid support: sprites can coexist with 3D stage (Option C).

UPBGE: planes at POSITIONS (world coords), texture swap via bge.texture,
       alpha tween for dissolve, move interpolation for M10.
Headless: state.shown_actors is source of truth; renderer just validates.

Accepted positions (SCRIPT_LANGUAGE_SPEC): left/center/right/far_left/far_right
and optional 'at' offset — e.g. show eileen happy at center
"""
from __future__ import annotations
try:
    import bge
    HAS_BGE = True
except ImportError:
    HAS_BGE = False

from ..core.vn_state import VNState
from .contract import (POSITIONS, SPRITE_MATERIAL, SPRITE_FALLBACK_TAG,
                       SPRITE_TAG_PREFIX, SPRITE_POOL, POSITION_EMPTY_PREFIX,
                       BG_PLANE, ASSET_SPRITES,
                       image_mode_from, sprite_color, SPRITE_FALLBACK_COLOR,
                       apply_object_color, plane_material,
                       apply_material_image, reset_material_palette)
import time

# Relative search prefixes for sprite images, relative to the .blend
# (repo layout <repo>/blend + <repo>/assets, packaged <pkg>/blend + <pkg>/assets).
SPRITE_PATH_PREFIXES = ("//", "//game/", "//../", "//../game/",
                        "//../../", "//../../game/")

def _dbg(msg: str):
    print(f"[SpriteRenderer] {msg}")

def _proj_resolution():
    # REMOVED: responsive layout — was reading gui_config resolution dict/list
    # and returning proj_w/proj_h for wpp calculations. Never worked reliably.
    # Now fixed 1280x720.
    return 1280.0, 720.0


def _renpy_place(obj, position):
    # REMOVED: responsive layout — was Ren'Py-true stage placement with
    # wpp = vh/proj_h, left-anchored virtual frame, xpos/xanchor logic,
    # image-size scaling, etc. Never worked reliably.
    # What was here: tried to read ortho, window W/H, proj_w/proj_h, compute
    # wpp, read image size from material, scale object, compute cx for left/
    # center/right using -vw/2 + ... formulas. Distracted other agents.
    # Now fixed simple positions.
    try:
        if position not in ("left", "center", "right", "far_left", "far_right"):
            return
        # Fixed world positions — simple, no aspect adaptation
        fixed = {
            "far_left": -6.0,
            "left": -3.0,
            "center": 0.0,
            "right": 3.0,
            "far_right": 6.0,
        }
        cx = fixed.get(position, 0.0)
        # Keep Y, set X, Z at ground level (0)
        try:
            y = obj.worldPosition[1]
        except Exception:
            y = -0.15
        obj.worldPosition = (cx, y, 0.0)
    except Exception as e:
        _dbg(f"renpy_place skipped ({position}): {e}")



# transition durations (seconds)
TRANS_DUR = {"dissolve": 0.4, "fade": 0.5, None: 0.0}

def _ensure_sprite_alpha(mat) -> None:
    """Wire TexImage.Alpha into the surface so sprite PNGs keep transparency.

    Converted bank materials link only Color→Emission; with no alpha the
    transparent PNG background renders as a black rectangle around the
    character (M29 parity, SDK tutorial comparison). Rebuild as
    Principled(Emission Color=Color, Emission Strength=1, Alpha=Alpha)
    with blended surface rendering.
    """
    if mat is None or getattr(mat, "upvn_alpha_fixed", False):
        return
    try:
        nt = getattr(mat, "node_tree", None)
        if nt is None:
            return
        tex = next((n for n in nt.nodes if n.type == "TEX_IMAGE"), None)
        out = next((n for n in nt.nodes if n.type == "OUTPUT_MATERIAL"), None)
        if tex is None or out is None:
            return
        principled = nt.nodes.new("ShaderNodeBsdfPrincipled")
        nt.links.new(tex.outputs["Color"], principled.inputs["Base Color"])
        if "Alpha" in tex.outputs and "Alpha" in principled.inputs:
            nt.links.new(tex.outputs["Alpha"], principled.inputs["Alpha"])
        for cname in ("Emission Color", "Emission Colour"):
            if cname in principled.inputs:
                nt.links.new(tex.outputs["Color"], principled.inputs[cname])
                break
        if "Emission Strength" in principled.inputs:
            principled.inputs["Emission Strength"].default_value = 1.0
        nt.links.new(principled.outputs["BSDF"], out.inputs["Surface"])
        for attr, val in (("blend_method", "BLEND"),
                          ("show_transparent_back", False)):
            try:
                setattr(mat, attr, val)
            except Exception:
                pass
        try:
            mat.surface_render_method = "BLENDED"
        except Exception:
            pass
        mat.upvn_alpha_fixed = True
    except Exception as e:  # pragma: no cover
        _dbg(f"sprite alpha fix skipped ({e})")


def _make_material_single_user(plane, tag: str) -> None:
    """Give a duplicated pool plane its own MASprite_<tag> material copy.

    Pool duplicates share the template mesh+material; without a single-user
    copy every tag would texture the same slot (the reason the old template
    carried one material per position).
    """
    try:
        bo = getattr(plane, "blenderObject", None)
        slots = getattr(bo, "material_slots", None) if bo is not None else None
        if slots and slots[0].material is not None:
            mat = slots[0].material.copy()
            mat.name = f"{SPRITE_MATERIAL}_{tag}"
            slots[0].material = mat
    except Exception:
        pass


class SpriteRenderer:
    def __init__(self, state: VNState):
        self.state = state
        # tag -> {"obj": bge object, "tex": Texture, "t0": start time, "transition": name}
        self.planes: dict[str, dict] = {}
        if HAS_BGE:
            try:
                sc = bge.logic.getCurrentScene()  # type: ignore
                for ob in sc.objects:
                    if str(ob.name).startswith(SPRITE_TAG_PREFIX):
                        ob.visible = False
            except Exception:
                pass

    def apply_event(self, event: dict):
        t = event.get("type")
        if t == "show":
            self.show(event["tag"], event["asset"], event.get("position"), event.get("transition"))
        elif t == "hide":
            self.hide(event["tag"], event.get("transition"))

    def show(self, tag: str, asset: str, position: str | None, transition: str | None):
        pos = position or "center"
        if pos not in POSITIONS:
            # allow custom marker name for hybrid — treat unknown as center but log
            pos = "center"
        # state already updated by interpreter (VNState.shown_actors[tag]=...)
        if HAS_BGE:
            self._bge_show(tag, asset, pos, transition)
        else:
            # headless validation: ensure no duplicate tag with different asset without replacement
            # interpreter already replaces; we just track
            self.planes[tag] = {"asset": asset, "position": pos, "transition": transition, "t0": time.time(), "tint": sprite_color(tag)}

    def hide(self, tag: str, transition: str | None):
        if HAS_BGE:
            self._bge_hide(tag, transition)
        # remove from tracking
        self.planes.pop(tag, None)

    # ---------------- BGE implementation
    def _bge_show(self, tag: str, asset: str, position: str, transition: str | None):
        try:
            scene = bge.logic.getCurrentScene()  # type: ignore
            # M26 policy: "color" never touches image files; "auto" tries
            # PNG/JPG/WebP first and falls back to the palette tint. The
            # policy lives on the VNController game property (image_mode).
            ctrl = scene.objects.get("VNController")
            mode = image_mode_from(ctrl)
            empty = scene.objects.get(f"{POSITION_EMPTY_PREFIX}{position}")
            pos_world = (empty.worldPosition if empty is not None
                         else POSITIONS[position])
            # Image bank first (converted projects): Sprite_img_<stem> planes
            # carry editor-assigned textures (tools/wire_converted_blend.py).
            # Resolved before pool duplication so a failed addObject cannot
            # abort the show (M29: SDK tutorial parity).
            bank = None
            if mode == "auto":
                _stem = asset.replace(" ", "_")
                _last = asset.split()[-1] if " " in asset else asset
                for key in (asset, _stem, _last, tag):
                    cand = scene.objects.get("Sprite_img_" + str(key).lower())
                    if cand is not None:
                        bank = cand
                        break
            if bank is not None:
                try:
                    # FIX: multi-sprite — only hide previous plane for SAME tag, not all Sprite_img_
                    # Previous code hid ALL Sprite_img_ planes, breaking multiple sprites
                    prev_info = self.planes.get(tag)
                    prev_obj = prev_info.get("obj") if prev_info else None
                    if prev_obj is not None and prev_obj is not bank:
                        try:
                            prev_obj.visible = False
                        except Exception:
                            pass
                    # Also hide the pool fallback plane for this tag if exists
                    old = scene.objects.get(f"{SPRITE_TAG_PREFIX}{tag}")
                    if old is not None and old is not bank:
                        old.visible = False
                    bank.visible = True
                    bank.worldPosition = pos_world  # type: ignore
                    _renpy_place(bank, position)
                    # M29 parity: sprite PNGs carry alpha; without blended
                    # transparency the plane shows a black rectangle around
                    # the character (SDK tutorial comparison).
                    _ensure_sprite_alpha(plane_material(bank))
                    self.planes[tag] = {"obj": bank, "asset": asset,
                                        "position": position,
                                        "t0": time.time(),
                                        "transition": transition,
                                        "bank": True}
                    _dbg(f"show {tag} '{asset}' → bank plane {bank.name}")
                    if not getattr(bge.logic, "_upvn_vis_logged", False):
                        bge.logic._upvn_vis_logged = True
                        print("[UPVN] visible:",
                              [o.name for o in scene.objects
                               if getattr(o, "visible", False)][:40])
                    if transition in ("dissolve", "fade"):
                        bank.color = (1, 1, 1, 0.0)
                        self.planes[tag].update({"t0": time.time()})
                    else:
                        bank.color = (1, 1, 1, 1.0)
                    return
                except Exception as e:
                    _dbg(f"show {tag} '{asset}' bank show failed ({e}) → pool")
            # One plane per tag; stage layout lives on Pos_<pos> empties
            # (position-empties refactor). Legacy blends still carry
            # per-position Sprite_<pos> planes — used as duplication source.
            plane_name = f"{SPRITE_TAG_PREFIX}{tag}"
            plane = scene.objects.get(plane_name)
            if plane is None:
                src = (scene.objects.get(SPRITE_POOL)
                       or scene.objects.get(f"{SPRITE_TAG_PREFIX}{position}")
                       or scene.objects.get(SPRITE_FALLBACK_TAG)
                       or scene.objects.get(BG_PLANE))
                if src is None:
                    _dbg(f"show {tag}: no plane object in scene — skipped")
                    return
                try:
                    # duplicate a template plane on the fly
                    plane = scene.addObject(src, src)
                except Exception as e:
                    # addObject needs its source in an inactive layer; fall
                    # back to reusing the source plane itself.
                    _dbg(f"show {tag}: addObject failed ({e}) — reuse source")
                    plane = src
                plane.name = plane_name
                _make_material_single_user(plane, tag)
            # place at correct world position (the empty owns the layout)
            plane.worldPosition = pos_world  # type: ignore
            plane.visible = True
            plane["upvn_asset"] = asset
            tex_path = None
            if mode == "auto":
                import bge.texture as vt
                import os
                stem = asset.replace(" ", "_")
                slash = asset.replace(" ", "/")
                last = asset.split()[-1] if " " in asset else "neutral"
                candidates = []
                for prefix in SPRITE_PATH_PREFIXES:
                    candidates.extend([
                        bge.logic.expandPath(f"{prefix}{ASSET_SPRITES}/{slash}.png"),
                        bge.logic.expandPath(f"{prefix}{ASSET_SPRITES}/{stem}.png"),
                        bge.logic.expandPath(f"{prefix}{ASSET_SPRITES}/{tag}.png"),
                    ])
                candidates.append(
                    bge.logic.expandPath(f"//assets/characters/{tag}/{last}.png"))
                for ext in (".png", ".jpg", ".webp"):
                    for prefix in SPRITE_PATH_PREFIXES:
                        candidates.append(
                            bge.logic.expandPath(f"{prefix}{ASSET_SPRITES}/{stem}{ext}"))
                # M29 parity: converted projects keep original file names with
                # spaces ("eileen happy.png") — try the raw asset name too.
                for ext in (".png", ".jpg", ".webp"):
                    for prefix in SPRITE_PATH_PREFIXES:
                        candidates.append(
                            bge.logic.expandPath(f"{prefix}{ASSET_SPRITES}/{asset}{ext}"))
                for p in candidates:
                    try:
                        if os.path.exists(p):
                            tex_path = p
                            break
                    except Exception:
                        continue
            def _palette_plane():
                # FIX: multi-sprite — only hide previous bank for SAME tag, not all
                try:
                    prev_info = self.planes.get(tag)
                    prev_obj = prev_info.get("obj") if prev_info else None
                    if prev_obj is not None and str(prev_obj.name).startswith("Sprite_img_"):
                        try:
                            if prev_obj is not plane:
                                prev_obj.visible = False
                        except Exception:
                            pass
                except Exception:
                    pass
                plane.visible = True
                return plane

            tint = sprite_color(tag)
            # an explicit `define e = Character("Eileen", color="#c8ffc8")`
            # wins over the curated/hash palette (Ren'Py authors expect their
            # color). The "#ffffff" DEFAULT is ignored — it would wash the
            # silhouette out white for every author who never set one.
            try:
                ch = self.state.characters.get(tag)
                ch_color = str(getattr(ch, "color", "") or "").strip()
                if ch_color and ch_color.lower() not in ("#ffffff", "white"):
                    h = ch_color.lstrip("#")
                    if len(h) >= 6:
                        tint = (int(h[0:2], 16) / 255.0,
                                int(h[2:4], 16) / 255.0,
                                int(h[4:6], 16) / 255.0, 1.0)
            except Exception:
                pass
            if tex_path:
                # (2) direct material node swap first (M26b): each Sprite_*
                # plane owns MASprite_<pos>, so sprites texture independently
                # FIX: don't hide all Sprite_img_ — only hide previous for same tag
                if apply_material_image(plane_material(plane), tex_path):
                    try:
                        prev_info = self.planes.get(tag)
                        prev_obj = prev_info.get("obj") if prev_info else None
                        if prev_obj is not None and str(prev_obj.name).startswith("Sprite_img_"):
                            if prev_obj is not plane:
                                prev_obj.visible = False
                    except Exception:
                        pass
                    plane.visible = True
                    self.planes[tag] = {"obj": plane, "asset": asset,
                                        "position": position,
                                        "t0": time.time(),
                                        "transition": transition,
                                        "tint": (1.0, 1.0, 1.0)}
                    _dbg(f"show {tag} '{asset}' → material texture {tex_path}")
                    _renpy_place(plane, position)
                    if transition in ("dissolve", "fade"):
                        plane.color = (1, 1, 1, 1.0)
                    return
                # (3) legacy bge.texture (blend-mode materials only)
                try:
                    img = vt.ImageFFmpeg(tex_path)
                    img.scale = False
                    try:
                        mat_id = vt.materialID(plane, SPRITE_MATERIAL)
                    except Exception:
                        mat_id = -1
                    if mat_id < 0:
                        # fallback plane may carry only a generic material — use the
                        # first slot (note: shared datablocks are a known limitation)
                        mat_id = 0
                    tex = vt.Texture(plane, mat_id)
                    tex.source = img
                    try:
                        for ob in scene.objects:
                            if str(ob.name).startswith("SPRIMG_"):
                                ob.visible = False
                    except Exception:
                        pass
                    self.planes[tag] = {"obj": plane, "tex": tex, "asset": asset, "position": position, "t0": time.time(), "transition": transition, "tint": tint}
                    _dbg(f"show {tag} '{asset}' → image {tex_path}")
                    _renpy_place(plane, position)
                    # start alpha fade for dissolve
                    if transition in ("dissolve", "fade"):
                        plane.color = (1,1,1,0.0)
                    else:
                        plane.color = (1,1,1,1.0)
                    return
                except Exception as e:
                    _dbg(f"show {tag} '{asset}' image bind failed ({e}) → palette tint")
            # no image (or bind failed) — paint the silhouette with the palette
            # tint so a missing texture must not equal "no sprite".
            _palette_plane()
            reset_material_palette(plane_material(plane))
            painted = apply_object_color(plane, tint)
            _dbg(f"show {tag} '{asset}' at {position} → palette tint "
                 f"(mode={mode}, painted={painted})")
            self.planes[tag] = {"obj": plane, "asset": asset, "position": position, "tint": tint}
            # start alpha fade for dissolve
            if transition in ("dissolve", "fade"):
                plane.color = (tint[0], tint[1], tint[2], 0.0)
            else:
                plane.color = (tint[0], tint[1], tint[2], 1.0)
        except Exception as e:
            print(f"[SpriteRenderer] show {tag} {asset} failed: {e}")

    def _bge_hide(self, tag: str, transition: str | None):
        try:
            info = self.planes.get(tag)
            if not info:
                return
            obj = info.get("obj")
            if obj:
                if transition in ("dissolve","fade"):
                    obj["upvn_fade_out"] = True
                    obj["upvn_fade_t0"] = time.time()
                    obj["upvn_fade_dur"] = TRANS_DUR.get(transition, 0.4)
                else:
                    obj.visible = False
        except Exception as e:
            print(f"[SpriteRenderer] hide {tag} failed: {e}")

    def get_interpolated_position(self, tag: str, now: float | None = None):
        """Headless helper: returns (x,y,z) interpolated for move, or final pos."""
        import time as _t
        actor = self.state.shown_actors.get(tag)
        if not actor:
            return None
        if now is None:
            now = _t.time()
        # check move fields
        if actor.move_from and actor.move_to and actor.move_t0:
            dur = actor.move_duration or 0.5
            t_raw = (now - actor.move_t0) / dur if dur>0 else 1.0
            t_raw = max(0.0, min(1.0, t_raw))
            if t_raw >= 1.0:
                return POSITIONS.get(actor.position, POSITIONS["center"])
            # easing
            try:
                from ..atl.easing import get_easing
                ease_fn = get_easing(actor.move_easing or "ease")
            except:
                ease_fn = lambda x: x
            t = ease_fn(t_raw)
            p0 = POSITIONS.get(actor.move_from, POSITIONS["center"])
            p1 = POSITIONS.get(actor.move_to, POSITIONS["center"])
            # lerp
            x = p0[0] + (p1[0]-p0[0])*t
            y = p0[1] + (p1[1]-p0[1])*t
            z = p0[2] + (p1[2]-p0[2])*t
            return (x,y,z)
        return POSITIONS.get(actor.position, POSITIONS["center"])

    def is_move_done(self, tag: str, now: float | None = None) -> bool:
        import time as _t
        actor = self.state.shown_actors.get(tag)
        if not actor or not actor.move_t0:
            return True
        if now is None:
            now = _t.time()
        return (now - actor.move_t0) >= (actor.move_duration or 0.5)

    def update(self, dt: float):
        """Per-frame tick for transition alpha + move (M10)."""
        if not HAS_BGE:
            # headless: clear finished moves so is_move_done reflects final? keep but we can clear after done for snapshot
            # Do not clear — let get_interpolated handle. But we can optionally snap position after done.
            return
        now = time.time()
        for tag, info in list(self.planes.items()):
            obj = info.get("obj")
            if not obj:
                continue
            trans = info.get("transition")
            t0 = info.get("t0")
            if trans in ("dissolve","fade") and t0:
                dur = TRANS_DUR.get(trans, 0.4)
                t = min(1.0, (now - t0)/dur) if dur>0 else 1.0
                # ease in-out; keep the palette tint, only ramp alpha
                tint = info.get("tint") or (1.0, 1.0, 1.0)
                alpha = t  # 0->1 fade in
                try:
                    obj.color = (tint[0], tint[1], tint[2], alpha)
                except Exception:
                    pass
                if t >= 1.0:
                    info["transition"] = None
        # M10 move interpolation BGE
        for tag, actor in list(self.state.shown_actors.items()):
            if actor.move_from and actor.move_to and actor.move_t0:
                dur = actor.move_duration or 0.5
                t_raw = (now - actor.move_t0) / dur if dur>0 else 1.0
                t_raw = max(0.0, min(1.0, t_raw))
                if t_raw >= 1.0:
                    # snap to final and clear move
                    try:
                        # find plane for this tag's target position
                        # reuse same plane object even if position changed — need to move it
                        info = self.planes.get(tag)
                        if info and info.get("obj"):
                            info["obj"].worldPosition = POSITIONS.get(actor.move_to, POSITIONS["center"])  # type: ignore
                    except: pass
                    # clear move to mark done
                    actor.move_from = None
                    actor.move_t0 = None
                    continue
                # easing lerp worldPosition
                try:
                    from ..atl.easing import get_easing
                    ease_fn = get_easing(actor.move_easing or "ease")
                except:
                    ease_fn = lambda x: x
                t = ease_fn(t_raw)
                p0 = POSITIONS.get(actor.move_from, POSITIONS["center"])
                p1 = POSITIONS.get(actor.move_to, POSITIONS["center"])
                x = p0[0] + (p1[0]-p0[0])*t
                y = p0[1] + (p1[1]-p0[1])*t
                z = p0[2] + (p1[2]-p0[2])*t
                info = self.planes.get(tag)
                if info and info.get("obj"):
                    try:
                        info["obj"].worldPosition = (x,y,z)  # type: ignore
                    except: pass

    def positions_ok(self) -> bool:
        """Headless check: all shown actors have valid positions."""
        for tag, actor in self.state.shown_actors.items():
            if actor.position not in POSITIONS and actor.position not in ("left","center","right","far_left","far_right"):
                return False
        return True
