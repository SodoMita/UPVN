"""
UPVN — Scene Manager (UPBGE + headless)

Handles background planes / 3D stage loading.
Headless: state already set by interpreter; here we record last transition for renderer.
UPBGE: swaps bge.texture on BG_Plane, handles fade/dissolve via shader/alpha tween.

In UPBGE:
- Backgrounds are textured planes parented to Orthographic Camera (Layer 0)
- Transitions are shader-based or alpha tween over N frames (fade/dissolve)
- 3D stages load .blend collections via bge.logic.LibLoad

This module is the thin adapter between interpreter events and bge API.
"""
from __future__ import annotations
try:
    import bge  # type: ignore
    HAS_BGE = True
except ImportError:
    HAS_BGE = False

from ..core.vn_state import VNState
from .contract import (BG_PLANE, BG_MATERIAL, ASSET_BACKGROUNDS,
                       image_mode_from, stage_color, apply_object_color,
                       plane_material, apply_material_image,
                       reset_material_palette)
import time

# Relative search prefixes for background images, relative to the .blend.
# '//../' and '//../../' cover repo (<repo>/blend + <repo>/assets) and
# packaged (<pkg>/blend + <pkg>/assets) layouts.
BG_PATH_PREFIXES = ("//", "//game/", "//../", "//../game/",
                    "//../../", "//../../game/")

def _dbg(msg: str):
    """Asset decisions are rare — print unconditionally so a debug tee
    (UPVN_DEBUG_TEE) or a console captures them."""
    print(f"[SceneManager] {msg}")

# The backdrop lives 10 units behind the stage: the player camera sits at
# y=-10, sprites/stage around y=-1..0 and the UI at y=-2..-9, so y=+6 keeps
# the background clear of everything that has to move in front of it (3D
# characters, camera pushes). Ortho projection: distance costs nothing.
BACKGROUND_LAYER = 0.0
TRANSITIONS = {"fade": 0.6, "dissolve": 0.45, None: 0.0}

def _fit_bg_to_view(plane) -> None:
    """Scale/center a backdrop plane so it **covers** the ortho viewport.

    Ren'Py fills the screen with a screen-sized background; a plane smaller than
    the frame leaves letterbox bands (field report: black bars left/right and a
    black strip below the dialogue box).

    Geometry: the bank planes are rotated 90 degrees on X, so their LOCAL
    bounding box maps local X -> world X (width) and local Y -> world Z
    (height).  The old maths targeted `ortho` on the width and `ortho*h/w` on
    the height — i.e. it produced a 15 x 8.44 backdrop inside the 26.7 x 15
    frame, which is why the picture never filled the screen.

    `cover` keeps the image's own aspect ratio: scale both axes by
    max(view_w / w, view_h / h) instead of stretching each axis independently.
    """
    try:
        import bge
        scene = bge.logic.getCurrentScene()
        cam = (getattr(scene, "active_camera", None)
               or getattr(scene, "camera", None))
        if cam is None:
            return
        ortho = float(getattr(cam, "ortho_scale", 0.0) or 0.0)
        if ortho <= 0.0:
            return
        w = float(bge.render.getWindowWidth() or 1280)
        h = float(bge.render.getWindowHeight() or 720)
        # KX_GameObject has no .dimensions — ask the bpy datablock.
        bo = getattr(plane, "blenderObject", None)
        dims = getattr(bo, "dimensions", None) if bo is not None else None
        if bo is None or dims is None or dims.x <= 0.0 or dims.y <= 0.0:
            return
        view_w = ortho * (w / h)      # frame width in world units
        view_h = ortho                # frame height in world units
        k = max(view_w / dims.x, view_h / dims.y) * 1.02   # cover + 2% margin
        if abs(k - 1.0) < 0.02:
            return
        try:
            ws = tuple(plane.worldScale)
            plane.worldScale = (ws[0] * k, ws[1] * k, ws[2])
        except Exception:
            try:
                s = tuple(bo.scale)
                bo.scale = (s[0] * k, s[1] * k, s[2])
            except Exception:
                return
        _dbg(f"bg fit: ortho={ortho} win={w}x{h} dims=({dims.x:.2f},{dims.y:.2f}) "
             f"-> cover x{k:.3f}")
        # recenter on the camera view axis at the plane's depth
        try:
            from mathutils import Vector
            fwd = cam.worldOrientation @ Vector((0.0, 0.0, -1.0))
            if abs(fwd.y) > 1e-6:
                t = (plane.worldPosition.y - cam.worldPosition.y) / fwd.y
                center = cam.worldPosition + fwd * t
                plane.worldPosition = (center.x, plane.worldPosition.y, center.z)
        except Exception:
            pass
    except Exception as e:  # pragma: no cover - render-only courtesy
        _dbg(f"bg fit skipped ({e})")


def _hide_template_stage(scene) -> None:
    """Hide the template's demo 3D classroom once a real background applies.

    Converted Ren'Py projects ship their own backgrounds; leaving the demo
    stage meshes visible drew desks/boards over them (M29 parity fix).
    """
    try:
        import bpy
        for cname in ("VN_3DStage",):
            coll = bpy.data.collections.get(cname)
            if coll is None:
                continue
            for ob in coll.objects:
                kob = scene.objects.get(ob.name)
                if kob is not None:
                    kob.visible = False
    except Exception as e:  # pragma: no cover
        _dbg(f"stage hide skipped ({e})")


class SceneManager:
    def __init__(self, state: VNState):
        self.state = state
        self._bg_object = None
        self._prev_bg: str | None = None
        self._transition_start: float | None = None
        self._transition_duration: float = 0.0
        self._transition_name: str | None = None

    def apply_event(self, event: dict):
        t = event.get("type")
        if t == "scene":
            self.set_background(event["asset"], event.get("transition"))
        elif t == "with":
            # standalone with — apply to last background
            self._transition_name = event.get("transition")
            self._transition_start = time.time()
            self._transition_duration = TRANSITIONS.get(self._transition_name, 0.5)
        elif t == "load_stage":
            # M26c: 3D-stage loading is StageManager's job (it existence-
            # checks every candidate path before LibLoad). This manager used
            # to LibLoad the raw expanded path with NO exists-check — a
            # missing stage file SIGSEGVs the player in UPBGE 0.50 before
            # the Python except can run (kernel log: blenderplayer sig=11;
            # full-sample game died at label classroom → load_stage
            # classroom_3d). Log-and-continue here; StageManager handles it.
            print(f"[SceneManager] load_stage '{event.get('stage')}' → "
                  "deferred to StageManager (existence-check + gated LibLoad "
                  "or baked-stage repositioning happen there)")

    def set_background(self, asset: str, transition: str | None = None):
        self._prev_bg = self.state.scene.background
        # state already updated by interpreter; record transition for visual
        if transition:
            self._transition_name = transition
            self._transition_start = time.time()
            self._transition_duration = TRANSITIONS.get(transition, 0.5)
        else:
            self._transition_name = None
        if HAS_BGE:
            self._swap_bge_texture(asset, transition)

    def _swap_bge_texture(self, asset: str, transition: str | None):
        if not HAS_BGE:
            return
        try:
            scene = bge.logic.getCurrentScene()  # type: ignore
            plane = scene.objects.get(BG_PLANE)
            if not plane:
                return
            # M26 policy: "color" (default for the template + samples) never
            # touches image files — the palette paints the stage, so a missing
            # texture cannot equal a missing background. The policy lives on
            # the VNController game property (image_mode); the plane is only a
            # fallback reader.
            ctrl = scene.objects.get("VNController")
            mode = image_mode_from(ctrl if ctrl is not None else plane)
            def _palette_bg():
                # any bank plane left visible from a previous 'scene'?
                try:
                    for ob in scene.objects:
                        if str(ob.name).startswith("BGIMG_"):
                            ob.visible = False
                except Exception:
                    pass
                plane.visible = True
                reset_material_palette(plane_material(plane))
                return apply_object_color(plane, stage_color(asset))

            if mode == "color":
                painted = _palette_bg()
                _dbg(f"stage '{asset}' → palette color "
                     f"(image_mode=color, painted={painted})")
                if transition in ("fade", "dissolve"):
                    plane["upvn_transition"] = transition
                    plane["upvn_transition_t0"] = time.time()
                return
            # image_mode == "auto": converted projects carry a baked image
            # bank (BGIMG_<stem> planes, textures assigned by
            # tools/wire_converted_blend.py — bge.texture cannot bind node
            # materials in UPBGE 0.50). Show the matching plane, hide the
            # rest; palette fallback when no bank plane exists.
            stems = [asset, asset.replace(" ", "_"),
                     asset.replace(" ", "/").replace("/", "_"),
                     asset.split()[-1] if " " in asset else asset]
            bank = None
            for stem in stems:
                cand = scene.objects.get("BGIMG_" + stem.lower())
                if cand is not None:
                    bank = cand
                    break
            if bank is not None:
                try:
                    for ob in scene.objects:
                        if str(ob.name).startswith("BGIMG_"):
                            ob.visible = (ob is bank)
                        # keep the palette plane behind the bank
                    plane.visible = False
                    bank.visible = True
                    try:
                        # older converted blends baked bank planes at y=0
                        bank.worldPosition = (bank.worldPosition.x,
                                              float(BACKGROUND_LAYER),
                                              bank.worldPosition.z)
                    except Exception:
                        pass
                    _fit_bg_to_view(bank)
                    _hide_template_stage(scene)
                    _dbg(f"stage '{asset}' → bank plane {bank.name}")
                    if transition in ("fade", "dissolve"):
                        bank["upvn_transition"] = transition
                        bank["upvn_transition_t0"] = time.time()
                    return
                except Exception as e:
                    _dbg(f"stage '{asset}' bank show failed ({e}) → palette")
            import os
            stems = [asset, asset.replace(" ", "_"),
                     asset.replace(" ", "/").replace("/", "_"),
                     asset.split()[-1] if " " in asset else asset]
            tex_path = None
            for stem in stems:
                for ext in (".png", ".jpg", ".webp"):
                    for prefix in BG_PATH_PREFIXES:
                        alt = bge.logic.expandPath(
                            f"{prefix}{ASSET_BACKGROUNDS}/{stem}{ext}")
                        if os.path.exists(alt):
                            tex_path = alt
                            break
                    if tex_path:
                        break
                if tex_path:
                    break
            if tex_path:
                # (2) direct material node swap — per-material, no
                # bge.texture needed (M26b; works on TexImage node graphs)
                if apply_material_image(plane_material(plane), tex_path):
                    try:
                        for ob in scene.objects:
                            if str(ob.name).startswith("BGIMG_"):
                                ob.visible = False
                    except Exception:
                        pass
                    plane.visible = True
                    _fit_bg_to_view(plane)
                    _hide_template_stage(scene)
                    _dbg(f"stage '{asset}' → material texture {tex_path}")
                    if transition in ("fade", "dissolve"):
                        plane["upvn_transition"] = transition
                        plane["upvn_transition_t0"] = time.time()
                    return
                # (3) legacy bge.texture (blend-mode materials only)
                import bge.texture as vt
                try:
                    mat_id = vt.materialID(plane, BG_MATERIAL)
                except Exception:
                    mat_id = -1
                if mat_id < 0:
                    mat_id = 0  # first material slot fallback
                try:
                    img = vt.ImageFFmpeg(tex_path)
                    img.scale = False
                    tex = vt.Texture(plane, mat_id)
                    tex.source = img
                    plane["upvn_tex"] = tex
                    _dbg(f"stage '{asset}' → bge.texture {tex_path}")
                except Exception as e:
                    _dbg(f"stage '{asset}' texture bind failed ({e}) → palette")
                    apply_object_color(plane, _palette_bg() or stage_color(asset))
                if transition in ("fade", "dissolve"):
                    plane["upvn_transition"] = transition
                    plane["upvn_transition_t0"] = time.time()
            else:
                painted = _palette_bg()
                _dbg(f"stage '{asset}' → no image found, palette color "
                     f"(painted={painted})")
                if transition in ("fade", "dissolve"):
                    plane["upvn_transition"] = transition
                    plane["upvn_transition_t0"] = time.time()
        except Exception as e:
            # headless or missing assets — not fatal
            print(f"[SceneManager] bge texture swap failed for {asset}: {e}")

    def is_transition_done(self) -> bool:
        if not self._transition_start:
            return True
        return (time.time() - self._transition_start) >= self._transition_duration

    def transition_alpha(self) -> float:
        if not self._transition_start or not self._transition_name:
            return 1.0
        elapsed = time.time() - self._transition_start
        dur = self._transition_duration or 0.5
        t = min(1.0, max(0.0, elapsed / dur))
        # ease out
        return t

    # M26c: _load_stage_bge removed — it LibLoad'ed unguarded paths and
    # segfaulted the player on missing stage files (StageManager owns this).

    # headless helper for screenshot verification
    def current_background(self) -> str | None:
        return self.state.scene.background
