UPVN editor add-on v0.6.0 — self-contained install zip
====================================================
Install:
  UPBGE/Blender -> Edit -> Preferences -> Add-ons ->
  Install from Disk... -> select this .zip -> enable
  "UPVN — Visual Novel Editor".

The engine/ and bge_frontend/ packages travel inside this zip;
no manual engine setup is needed (the add-on can even import the
engine directly from the compressed archive).

First steps (see README.md in the repo):
  1. UPVN tab (View3D sidebar) -> Create Project
  2. (UPBGE only) Setup Scene — wires the running scene once
  3. Add characters / scenes / dialogue / menus with clicks
  4. Validate -> checks your script;  Preview -> screenshot
  5. Press P to play.

Template blend inside: blend/UPVN_Template.blend
License: MIT (see LICENSE).
