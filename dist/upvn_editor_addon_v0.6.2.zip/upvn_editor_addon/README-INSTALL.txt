UPVN editor add-on v0.6.2 — self-contained install zip
====================================================
Install:
  UPBGE/Blender -> Edit -> Preferences -> Add-ons ->
  Install from Disk... -> select this .zip -> enable
  "UPVN — Visual Novel Editor".

The engine/ and bge_frontend/ packages travel inside this zip
(inside the upvn_editor_addon folder); Blender extracts the zip on
install, so no manual engine setup is needed.

If you previously installed v0.6.0 by unpacking it by hand, remove
the leftover  addons/engine  and  addons/bge_frontend  folders —
they were zip-root duplicates and are not needed anymore.

First steps (see README.md in the repo):
  1. UPVN tab (View3D sidebar) -> Create Project
  2. (UPBGE only) Setup Scene — wires the running scene once
  3. Add characters / scenes / dialogue / menus with clicks
  4. Validate -> checks your script;  Preview -> screenshot
  5. Press P to play.

Template blend inside: blend/UPVN_Template.blend
License: MIT (see LICENSE).
